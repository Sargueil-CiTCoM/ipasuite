.. automodule:: {{ fullname }}

