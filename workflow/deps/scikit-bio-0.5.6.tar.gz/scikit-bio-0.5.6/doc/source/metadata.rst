.. automodule:: skbio.metadata
