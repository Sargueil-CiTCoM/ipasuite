.. automodule:: skbio.diversity
