.. automodule:: skbio.stats
