Caporaso lab meeting presentation
=================================

A presentation of scikit-bio, its goals, and a few live demos.

This was presented at the Caporaso lab meeting on 05/13/2014. It was tested
against pre-0.1.0 scikit-bio so may not work with newer versions of scikit-bio,
due to inevitable API changes that will happen. Tested using IPython Notebook
2.0.0 in slideshow mode.
